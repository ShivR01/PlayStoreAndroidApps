package com.Task2ShivR.sanfitness18003959poe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;

public class Profile extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private FirebaseUser currentuser;
    private DatabaseReference myRef;
    private String userID;
    private String impMet;

    private EditText user,dob,height,steps,target,current;
    private Spinner measure;
    private ProgressBar profBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        InitializeFields();

        mAuth = FirebaseAuth.getInstance();
        currentuser = mAuth.getCurrentUser();
        userID = currentuser.getUid();
        profBar.setVisibility(View.VISIBLE);
        
        mDatabase = FirebaseDatabase.getInstance();
        myRef = mDatabase.getReference("Users");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showData(dataSnapshot.child(userID));
                profBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void onSaveClick(View view)
    {
        checkImpMet();
        User fbUser = new User(user.getText().toString(), FirebaseAuth.getInstance().getCurrentUser().getEmail(), dob.getText().toString(), measure.getSelectedItem().toString(), height.getText().toString(), steps.getText().toString(), current.getText().toString(), target.getText().toString());
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Users");
        myRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(fbUser).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if (task.isSuccessful())
                {
                    Toast.makeText(Profile.this, "User profile edited successfully...", Toast.LENGTH_SHORT).show();
                }else{
                    String message = task.getException().toString();
                    Toast.makeText(Profile.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void checkImpMet()
    {
        DecimalFormat df = new DecimalFormat("0");
        String measurement;
        double h,w,tw;
        h = Double.parseDouble(height.getText().toString());
        w = Double.parseDouble(current.getText().toString());
        tw = Double.parseDouble(target.getText().toString());
        measurement = measure.getSelectedItem().toString();

        if ((measurement != impMet) && (measurement.equals("Imperial")))
        {
            w = w * 2.205;
            tw = tw * 2.205;
            h = h / 30.48;

            height.setText((df.format(h)));
            current.setText(df.format(w));
            target.setText(df.format(tw));
            impMet = measure.getSelectedItem().toString();
        }
        if ((measurement != impMet) && (measurement.equals("Metric")))
        {
            w = w / 2.205;
            tw = tw / 2.205;
            h = h * 30.48;

            height.setText((df.format(h)));
            current.setText(df.format(w));
            target.setText(df.format(tw));
            impMet = measure.getSelectedItem().toString();
        }
    }

    private void showData(DataSnapshot dataSnapshot)
    {

        user.setText(dataSnapshot.getValue(User.class).getUserName());
        dob.setText(dataSnapshot.getValue(User.class).getDOB());
        height.setText(dataSnapshot.getValue(User.class).getUserHeight());
        current.setText(dataSnapshot.getValue(User.class).getCurrentWeight());

        ArrayAdapter myAdap = (ArrayAdapter) measure.getAdapter();
        int spinnerPosition = myAdap.getPosition(dataSnapshot.getValue(User.class).getMeasurement());
        measure.setSelection(spinnerPosition);

        target.setText(dataSnapshot.getValue(User.class).getTargetWeight());
        steps.setText(dataSnapshot.getValue(User.class).getSteps());
        impMet = measure.getSelectedItem().toString();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.side_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_contact)
        {
            startActivity(new Intent(Profile.this, Contact.class));
        }

        if (id == R.id.menu_logout)
        {
            Intent intent = new Intent(Profile.this, login.class);
            mAuth.signOut();
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }

        if (id == R.id.menu_profile)
        {
            Toast.makeText(this, "Already on Profile page...", Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }

    private void InitializeFields()
    {
        user = findViewById(R.id.etUser);
        dob = findViewById(R.id.etDob);
        dob.setEnabled(false);
        height = findViewById(R.id.etheight);
        steps = findViewById(R.id.etSteps);
        target = findViewById(R.id.etTarget);
        current = findViewById(R.id.etCurrent);
        measure = findViewById(R.id.spnMeasure);

        profBar = findViewById(R.id.profileProgBar);
    }
}
