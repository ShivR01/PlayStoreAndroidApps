package com.Task2ShivR.sanfitness18003959poe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class WeightJournal extends AppCompatActivity {

    BarChart barChart;

    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private FirebaseUser currentuser;
    private DatabaseReference myRef;
    private String userID;
    private String step;
    private String water;
    private String targetWeight;
    private String currentWeight;

    private ListView listWeight;
    private EditText newWeight;

    final String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_journal);

        listWeight = findViewById(R.id.lvWeight);
        newWeight = findViewById(R.id.etNewWeight);
        barChart = findViewById(R.id.bargraph);

        mAuth = FirebaseAuth.getInstance();
        currentuser = mAuth.getCurrentUser();
        userID = currentuser.getUid();
        mDatabase = FirebaseDatabase.getInstance();

        DatabaseReference rootRef = mDatabase.getInstance().getReference();
        myRef = rootRef.child("Fitness");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showData(dataSnapshot.child(userID).child(date));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        mDatabase = FirebaseDatabase.getInstance();
        myRef = mDatabase.getReference("Users");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showDataUser(dataSnapshot.child(userID));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void showDataUser(DataSnapshot dataSnapshot)
    {
        targetWeight = (dataSnapshot.getValue(User.class).getTargetWeight());
        barCreate();
    }

    public void onAddClick(View view)
    {
        if (TextUtils.isEmpty(newWeight.getText().toString())){
            Toast.makeText(this, "Please enter weight...", Toast.LENGTH_SHORT).show();
        }else{
            Fitness fit = new Fitness(newWeight.getText().toString(),step,water);
            FirebaseDatabase.getInstance().getReference("Fitness").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(date).setValue(fit).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful())
                    {
                        Toast.makeText(WeightJournal.this, "New weight added successfully..", Toast.LENGTH_SHORT).show();
                    }else{
                        String message = task.getException().toString();
                        Toast.makeText(WeightJournal.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                    }
                }
            });

            FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("currentWeight").setValue(newWeight.getText().toString());
        }
    }

    private void showData(DataSnapshot dataSnapshot) {
        ArrayList<String> array = new ArrayList<>();
        array.add(date+":");
        array.add("Steps: "+(dataSnapshot.getValue(Fitness.class).getStepCount()));
        array.add("Water: "+(dataSnapshot.getValue(Fitness.class).getWater()));
        array.add("Weight: "+(dataSnapshot.getValue(Fitness.class).getWeightLog()));
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,array);

        listWeight.setAdapter(adapter);

        step = (dataSnapshot.getValue(Fitness.class).getStepCount());
        water = (dataSnapshot.getValue(Fitness.class).getWater());
        currentWeight = (dataSnapshot.getValue(Fitness.class).getWeightLog());
    }

    public void barCreate()
    {
        ArrayList<BarEntry> barEntries = new ArrayList<>();
        barEntries.add(new BarEntry(Float.valueOf(currentWeight),0));
        barEntries.add(new BarEntry(Float.valueOf(targetWeight),1));
        barEntries.add(new BarEntry(Float.valueOf(40),2));

        BarDataSet barDataSet = new BarDataSet(barEntries,"Weights");

        ArrayList<String> ctWeight = new ArrayList<>();
        ctWeight.add("Current Weight");
        ctWeight.add("Target Weight");
        ctWeight.add("Random bar");

        BarData theData = new BarData(ctWeight,barDataSet);
        barChart.setData(theData);

    }

    @Override
    protected void onStart()
    {
        super.onStart();

        if (currentuser == null)
        {
            startActivity(new Intent(WeightJournal.this, login.class));
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.side_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_contact)
        {
            startActivity(new Intent(WeightJournal.this, Contact.class));
        }

        if (id == R.id.menu_logout)
        {
            Intent intent = new Intent(WeightJournal.this, login.class);
            mAuth.signOut();
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }

        if (id == R.id.menu_profile)
        {
            startActivity(new Intent(WeightJournal.this, Profile.class));
        }

        return super.onOptionsItemSelected(item);
    }
}
