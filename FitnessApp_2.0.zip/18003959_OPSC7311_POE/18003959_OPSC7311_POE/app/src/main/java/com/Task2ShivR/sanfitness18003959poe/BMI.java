package com.Task2ShivR.sanfitness18003959poe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.text.DecimalFormat;

public class BMI extends AppCompatActivity {

    private FirebaseAuth mAuth;

    private EditText height,weight;
    private TextView score,status;
    String[] Statuses = {"Severe Thinness", "Moderate Thinness", "Mild Thinness", "Normal", "Overweight", "Obese class 1", "Obese class 2", "Obese class 3"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);

        mAuth = FirebaseAuth.getInstance();
        InitializeFields();
    }

    public void onCalculateClick(View view)
    {
        DecimalFormat df = new DecimalFormat("0.00");
        double sc = 0;
        String st;

        sc = calcScore(height.getText().toString(),weight.getText().toString());
        st = getStatus(sc);

        score.setText(df.format(sc));
        status.setText(st);
    }

    private String getStatus(double sc)
    {
        String s ="";
        if (sc < 16)
        {
            s = Statuses[0];
        }else
        if (sc < 17)
        {
            s = Statuses[1];
        }else
        if (sc < 18.5)
        {
            s = Statuses[2];
        }else
        if (sc < 25)
        {
            s = Statuses[3];
        }else
        if (sc < 30)
        {
            s = Statuses[4];
        }else
        if (sc < 35)
        {
            s = Statuses[5];
        }else
        if (sc < 40)
        {
            s = Statuses[6];
        }else
        if (sc > 40)
        {
            s = Statuses[7];
        }
        return s;
    }

    private double calcScore(String height, String weight)
    {
        double h,w,s;
        h = Double.parseDouble(height);
        w = Double.parseDouble(weight);
        s = w / (h * h);
        return s;
    }


    private void InitializeFields()
    {
        height = findViewById(R.id.etBmiHeight);
        weight = findViewById(R.id.etBmiWeight);
        score = findViewById(R.id.tvScore);
        status = findViewById(R.id.tvStatus);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.side_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_contact)
        {
            startActivity(new Intent(BMI.this, Contact.class));
        }

        if (id == R.id.menu_logout)
        {
            Intent intent = new Intent(BMI.this, login.class);
            mAuth.signOut();
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }

        if (id == R.id.menu_profile)
        {
            startActivity(new Intent(BMI.this, Profile.class));
        }

        return super.onOptionsItemSelected(item);
    }


}
