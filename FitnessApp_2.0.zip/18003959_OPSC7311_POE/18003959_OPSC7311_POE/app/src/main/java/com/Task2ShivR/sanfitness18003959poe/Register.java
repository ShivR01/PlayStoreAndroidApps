package com.Task2ShivR.sanfitness18003959poe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Register extends AppCompatActivity {

    private FirebaseAuth mAuth;

    private EditText user,pass,email,dob,height,steps,target,current;
    private Spinner measure;
    private DatePickerDialog picker;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        InitializeFields();
        PickDate();
        progressBar.setVisibility(View.GONE);

        mAuth = FirebaseAuth.getInstance();
        mAuth.signOut();
    }

    private void InitializeFields()
    {
        user = findViewById(R.id.etEmail);
        pass = findViewById(R.id.etPass);
        email = findViewById(R.id.etEmail);
        dob = findViewById(R.id.etDob);
        height = findViewById(R.id.etHeight);
        steps = findViewById(R.id.etSteps);
        target = findViewById(R.id.etTw);
        current = findViewById(R.id.etCw);
        measure = findViewById(R.id.spinMeasure);

        progressBar = findViewById(R.id.progressbar);
    }

    private void PickDate()
    {
        dob.setInputType(InputType.TYPE_NULL);
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);

                picker = new DatePickerDialog(Register.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                dob.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, year, month, day);
                picker.show();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (mAuth.getCurrentUser() != null) {
            //handle the already login user
        }
    }

    public void OnRegisterClick(View view)
    {
        createAccount();
    }

    private void createAccount()
    {
        final String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String userEmail = email.getText().toString();
        String password = pass.getText().toString();

        if (TextUtils.isEmpty(userEmail) || TextUtils.isEmpty(password) || TextUtils.isEmpty(pass.getText().toString()) || TextUtils.isEmpty(dob.getText().toString()) || TextUtils.isEmpty(height.getText().toString()) || TextUtils.isEmpty(steps.getText().toString()) || TextUtils.isEmpty(target.getText().toString()) || TextUtils.isEmpty(current.getText().toString()))
        {
            Toast.makeText(this, "Please enter all fields...", Toast.LENGTH_SHORT).show();
        }else{

            progressBar.setVisibility(View.VISIBLE);
            mAuth.createUserWithEmailAndPassword(userEmail,password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful())
                            {
                                User fbUser = new User(user.getText().toString(), email.getText().toString(), dob.getText().toString(), measure.getSelectedItem().toString(), height.getText().toString(), steps.getText().toString(), current.getText().toString(), target.getText().toString());
                                FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference myRef = database.getReference("Users");
                                myRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(fbUser).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {

                                        if (task.isSuccessful())
                                        {
                                            Toast.makeText(Register.this, "User created successfully...", Toast.LENGTH_SHORT).show();
                                        }else{
                                            String message = task.getException().toString();
                                            Toast.makeText(Register.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });

                                Fitness fit = new Fitness(current.getText().toString(),"0","0");
                                FirebaseDatabase.getInstance().getReference("Fitness").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(date).setValue(fit).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        progressBar.setVisibility(View.GONE);
                                        if (task.isSuccessful())
                                        {
                                            Toast.makeText(Register.this, "Account created successfully...", Toast.LENGTH_SHORT).show();
                                            startActivity(new Intent(Register.this, login.class));
                                        }else{
                                            String message = task.getException().toString();
                                            Toast.makeText(Register.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });

                            }else
                            {
                                String message = task.getException().toString();
                                Toast.makeText(Register.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }
}
