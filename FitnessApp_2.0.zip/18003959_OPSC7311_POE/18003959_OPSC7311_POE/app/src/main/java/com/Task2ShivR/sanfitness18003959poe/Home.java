package com.Task2ShivR.sanfitness18003959poe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, SensorEventListener {

    SensorManager sensorManager;
    boolean running = false;

    Button steps;
    TextView totSteps;
    final String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

    private FirebaseUser currentuser;
    private FirebaseAuth mAuth;
    private DatabaseReference myRef;
    private FirebaseDatabase mDatabase;
    private String userID;
    private String currentWeight ="0";
    private String water = "0";
    private String stepTarget;
    private String stepNewDate;

    private double count = 1;
    double num,num2;

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        sensorManager =(SensorManager) getSystemService(Context.SENSOR_SERVICE);

        mAuth = FirebaseAuth.getInstance();
        currentuser = mAuth.getCurrentUser();
        userID = currentuser.getUid();

        navView();

        InitializeFields();


        mDatabase = FirebaseDatabase.getInstance();
        myRef = mDatabase.getReference("Users");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showDataUser(dataSnapshot.child(userID));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mDatabase = FirebaseDatabase.getInstance();
        myRef = mDatabase.getReference("Fitness");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showDataFitness(dataSnapshot.child(userID).child(date));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        setNewDate();
    }

    private void showDataUser(DataSnapshot dataSnapshot)
    {
        currentWeight = (dataSnapshot.getValue(User.class).getCurrentWeight());
        stepTarget = (dataSnapshot.getValue(User.class).getSteps());
        totSteps.setText((steps.getText().toString())+"/"+stepTarget);
    }

    private void showDataFitness(DataSnapshot dataSnapshot)
    {
         water = (dataSnapshot.getValue(Fitness.class).getWater());
         stepNewDate = (dataSnapshot.getValue(Fitness.class).getStepCount());
         steps.setText(stepNewDate);
         num2 = Double.valueOf(stepNewDate);

    }

    private void setNewDate()
    {
        Fitness fit = new Fitness(currentWeight,steps.getText().toString(),water);
        FirebaseDatabase.getInstance().getReference("Fitness").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(date).setValue(fit);
    }

    @Override
    protected void onStart()
    {
        super.onStart();

        if (currentuser == null)
        {
            startActivity(new Intent(Home.this, login.class));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.side_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_contact)
        {
            startActivity(new Intent(Home.this, Contact.class));
        }

        if (id == R.id.menu_logout)
        {
            Intent intent = new Intent(Home.this, login.class);
            mAuth.signOut();
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }

        if (id == R.id.menu_profile)
        {
            startActivity(new Intent(Home.this, Profile.class));
        }

        if (mToggle.onOptionsItemSelected(item))
        {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
    {
        int id = menuItem.getItemId();

        if (id == R.id.nav_weightLog)
        {
            setNewDate();
            startActivity(new Intent(Home.this, WeightJournal.class));
        }
        if (id == R.id.nav_calc)
        {
            startActivity(new Intent(Home.this, BMI.class));
        }
        if (id == R.id.nav_water)
        {
            startActivity(new Intent(Home.this, Water.class));
        }
        if (id == R.id.nav_camera)
        {
            startActivity(new Intent(Home.this, Images.class));
        }
        if (id == R.id.nav_stopWatch)
        {
            startActivity(new Intent(Home.this, StopWatch.class));
        }
        if (id == R.id.nav_contact)
        {
            startActivity(new Intent(Home.this, Contact.class));
        }
        return false;
    }

    private void InitializeFields()
    {
       steps = findViewById(R.id.btnSteps);
       totSteps = findViewById(R.id.tvSteps);
    }

    private void navView()
    {
        mDrawerLayout = findViewById(R.id.drawer);
        mToggle=new ActionBarDrawerToggle(this,mDrawerLayout,R.string.open,R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView = findViewById(R.id.navView);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        running = true;
        Sensor countSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (countSensor!=null)
        {
            sensorManager.registerListener(this,countSensor,sensorManager.SENSOR_DELAY_UI);
        }else
            {
                Toast.makeText(this, "Sensor not found...", Toast.LENGTH_SHORT).show();
            }
    }

    @Override
    protected void onPause() {
        super.onPause();
        running = false;
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent)
    {
        num = sensorEvent.values[0];
        steps.setText(String.valueOf(num2+((num-num)+count)));
        count = count+1;
        totSteps.setText((steps.getText().toString())+"/"+stepTarget);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
