package com.Task2ShivR.sanfitness18003959poe;

import com.google.firebase.database.Exclude;

public class User {
    public String UserName;
    public String Email;
    public String DOB;
    public String Measurement;
    public String userHeight;
    public String steps;
    public String currentWeight;
    public String targetWeight;

    public User() {

    }

    public User(String userName, String email, String DOB, String measurement, String userHeight, String steps, String currentWeight, String targetWeight) {
        this.UserName = userName;
        this.Email = email;
        this.DOB = DOB;
        this.Measurement = measurement;
        this.userHeight = userHeight;
        this.steps = steps;
        this.currentWeight = currentWeight;
        this.targetWeight = targetWeight;
    }

    @Exclude
    public String getUserName() {
        return UserName;
    }

    @Exclude
    public void setUserName(String userName) {
        UserName = userName;
    }

    @Exclude
    public String getEmail() {
        return Email;
    }

    @Exclude
    public void setEmail(String email) {
        Email = email;
    }
    @Exclude
    public String getDOB() {
        return DOB;
    }
    @Exclude
    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    @Exclude
    public String getMeasurement() {
        return Measurement;
    }

    @Exclude
    public void setMeasurement(String measurement) {
        Measurement = measurement;
    }

    @Exclude
    public String getUserHeight() {
        return userHeight;
    }

    @Exclude
    public void setUserHeight(String userHeight) {
        this.userHeight = userHeight;
    }

    @Exclude
    public String getSteps() {
        return steps;
    }

    @Exclude
    public void setSteps(String steps) {
        this.steps = steps;
    }

    @Exclude
    public String getCurrentWeight() {
        return currentWeight;
    }

    @Exclude
    public void setCurrentWeight(String currentWeight) {
        this.currentWeight = currentWeight;
    }

    @Exclude
    public String getTargetWeight() {
        return targetWeight;
    }

    @Exclude
    public void setTargetWeight(String targetWeight) {
        this.targetWeight = targetWeight;
    }
}