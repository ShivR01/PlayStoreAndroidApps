package com.Task2ShivR.sanfitness18003959poe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class Contact extends AppCompatActivity {
    ImageButton dial;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        dial = findViewById(R.id.btnDial);
        mAuth = FirebaseAuth.getInstance();
    }

    public void onDialClick(View v) {

        if (ContextCompat.checkSelfPermission(Contact.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(Contact.this, new String[]{Manifest.permission.CALL_PHONE},1);
        }else{
            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:1234567890")));
        }

    }

    public void onMail(View v) {

        startActivity(new Intent(Contact.this, Email.class));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.side_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_contact)
        {
            Toast.makeText(this, "Already on Contact page...", Toast.LENGTH_SHORT).show();
        }

        if (id == R.id.menu_logout)
        {
            Intent intent = new Intent(Contact.this, login.class);
            mAuth.signOut();
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }

        if (id == R.id.menu_profile)
        {
            startActivity(new Intent(Contact.this, Profile.class));
        }

        return super.onOptionsItemSelected(item);
    }
}
