package com.Task2ShivR.sanfitness18003959poe;

import com.google.firebase.database.Exclude;

public class Fitness {
    public String weightLog;
    public String stepCount;
    public String water;
    public String logDate;

    public Fitness() {

    }

    public Fitness(String weightLog, String stepCount, String water) {
        this.weightLog = weightLog;
        this.stepCount = stepCount;
        this.water = water;
    }
    @Exclude
    public String getWeightLog() {
        return weightLog;
    }

    @Exclude
    public void setWeightLog(String weightLog) {
        this.weightLog = weightLog;
    }

    @Exclude
    public String getStepCount() {
        return stepCount;
    }

    @Exclude
    public void setStepCount(String stepCount) {
        this.stepCount = stepCount;
    }

    @Exclude
    public String getWater() {
        return water;
    }

    @Exclude
    public void setWater(String water) {
        this.water = water;
    }

    @Exclude
    public String getLogDate() {
        return logDate;
    }

    @Exclude
    public void setLogDate(String logDate) {
        this.logDate = logDate;
    }
}