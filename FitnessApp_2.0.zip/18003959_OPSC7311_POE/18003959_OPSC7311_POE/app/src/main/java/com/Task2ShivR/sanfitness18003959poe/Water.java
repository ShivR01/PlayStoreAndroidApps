package com.Task2ShivR.sanfitness18003959poe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Water extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser currentuser;
    private DatabaseReference myRef;
    private FirebaseDatabase mDatabase;
    private String userID;


    ImageButton minus,plus;
    TextView tot;
    final String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water);

        InitializeFields();

        mAuth = FirebaseAuth.getInstance();
        currentuser = mAuth.getCurrentUser();
        userID = currentuser.getUid();

        mDatabase = FirebaseDatabase.getInstance();
        myRef = mDatabase.getReference("Fitness");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showData(dataSnapshot.child(userID).child(date));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void showData(DataSnapshot dataSnapshot)
    {
        tot.setText((dataSnapshot.getValue(Fitness.class).getWater()));
    }

    public void onMinus(View view)
    {
        int w = Integer.parseInt(tot.getText().toString());
        if (w == 0)
        {
            Toast.makeText(this, "Cannot be negative...", Toast.LENGTH_SHORT).show();
        }else
            {
                w = w-1;
                FirebaseDatabase.getInstance().getReference("Fitness").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(date).child("water").setValue(String.valueOf(w));
                tot.setText(String.valueOf(w));
            }
    }

    public void onPlus(View view)
    {
        int w = Integer.parseInt(tot.getText().toString());
        if (w > 8)
        {
            Toast.makeText(this, "You have reached the recommended 8 glasses of water for the day...", Toast.LENGTH_LONG).show();
        }else
        {
            w = w+1;
            FirebaseDatabase.getInstance().getReference("Fitness").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(date).child("water").setValue(String.valueOf(w));
            tot.setText(String.valueOf(w));

        }
    }

    private void InitializeFields()
    {
        minus = findViewById(R.id.btnMinus);
        plus = findViewById(R.id.btnPlus);
        tot = findViewById(R.id.tvWater);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.side_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_contact)
        {
            startActivity(new Intent(Water.this, Contact.class));
        }

        if (id == R.id.menu_logout)
        {
            Intent intent = new Intent(Water.this, login.class);
            mAuth.signOut();
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }

        if (id == R.id.menu_profile)
        {
            startActivity(new Intent(Water.this, Profile.class));
        }


        return super.onOptionsItemSelected(item);
    }
}
