package com.Task2ShivR.sanfitness18003959poe;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;

public class CaptureImage extends AppCompatActivity {

    private Button capUp;
    private ImageView mImage;

    private static final int CAMERA_REQUEST_CODE = 1;

    private StorageReference mStorage;
    private ProgressBar pBar;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capture_image);

        mStorage = FirebaseStorage.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        mImage = findViewById(R.id.imgvCapture);
        capUp = findViewById(R.id.btnUpload);

        pBar = findViewById(R.id.pBar);
        pBar.setVisibility(View.GONE);

        capUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                if (ContextCompat.checkSelfPermission(CaptureImage.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(CaptureImage.this, new String[]{Manifest.permission.CAMERA},1);
                }else{
                    startActivityForResult(intent, CAMERA_REQUEST_CODE);
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK)
        {
              pBar.setVisibility(View.VISIBLE);
            if (data !=null && data.getExtras() != null)
            {
                Bitmap imageBitmap = (Bitmap) data.getExtras().get("data");
                mImage.setImageBitmap(imageBitmap);
                encodeBitmapAndSaveToFirebase(imageBitmap);
                pBar.setVisibility(View.GONE);
            }

        }
    }

    public void encodeBitmapAndSaveToFirebase(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        String imageEncoded = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
        FirebaseDatabase.getInstance().getReference("Photo").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(imageEncoded);
        Toast.makeText(this, "Image successfully uploaded to firebase...", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.side_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_contact)
        {
            startActivity(new Intent(CaptureImage.this, Contact.class));
        }

        if (id == R.id.menu_logout)
        {
            Intent intent = new Intent(CaptureImage.this, login.class);
            mAuth.signOut();
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }

        if (id == R.id.menu_profile)
        {
            startActivity(new Intent(CaptureImage.this, Profile.class));
        }

        return super.onOptionsItemSelected(item);
    }
}
