package com.Task2ShivR.sanfitness18003959poe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class login extends AppCompatActivity {

    private EditText email,pass;
    private ProgressBar progressBar;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        InitializeFields();
        progressBar.setVisibility(View.GONE);
        mAuth = FirebaseAuth.getInstance();
    }

    public void onLoginClick(View view)
    {
        userLogin();
    }

    private void userLogin()
    {
        String userEmail = email.getText().toString();
        String password = pass.getText().toString();

        if (TextUtils.isEmpty(userEmail) || TextUtils.isEmpty(password))
        {
            Toast.makeText(this, "Please enter all fields...", Toast.LENGTH_SHORT).show();
        }else
            {
                progressBar.setVisibility(View.VISIBLE);
                mAuth.signInWithEmailAndPassword(userEmail,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressBar.setVisibility(View.GONE);
                        if (task.isSuccessful())
                        {
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            startActivity(new Intent(login.this, Home.class));
                            Toast.makeText(login.this, "Signed in successfully", Toast.LENGTH_SHORT).show();
                        }else
                            {
                                String message = task.getException().toString();
                                Toast.makeText(login.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                            }
                    }
                });
            }
    }

    public void onRegisterClick(View view)
    {
        startActivity(new Intent(login.this, Register.class));
    }

    private void InitializeFields()
    {
        email = findViewById(R.id.etEmail);
        pass = findViewById(R.id.etPassword);
        progressBar = findViewById(R.id.progressbar3);
    }
}
