package com.example.sanmaps;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.AnimationDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener {

    protected LocationManager locationManager;
    TextView latios,latias,city,country;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ConstraintLayout constraintLayout = findViewById(R.id.layout);                                   //Animated background
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        isLocationEnabled(MainActivity.this);

        latias = findViewById(R.id.tvLat);
        latios = findViewById(R.id.tvLon);
        city = findViewById(R.id.edtCity2);
        country = findViewById(R.id.edtCountry2);
        progressBar = findViewById(R.id.progressbarmain);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
            return;
        }

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, this);
    }

    public void isLocationEnabled(Context context)     //Checks if location and internet and available
    {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        LocationManager lm = (LocationManager)
                getSystemService(Context. LOCATION_SERVICE ) ;
        boolean gps_enabled = false;
        boolean network_enabled = false;
        try {
            gps_enabled = lm.isProviderEnabled(LocationManager. GPS_PROVIDER ) ;
        } catch (Exception e) {
            e.printStackTrace() ;
        }
        try {
            network_enabled = lm.isProviderEnabled(LocationManager. NETWORK_PROVIDER ) ;
        } catch (Exception e) {
            e.printStackTrace() ;
        }
        if (gps_enabled == true && network_enabled == true && activeNetworkInfo != null && activeNetworkInfo.isConnected()) {

        }else
            {
                new AlertDialog.Builder(MainActivity. this )
                        .setMessage( "Enable GPS and Internet then click Refresh." )
                        .setPositiveButton( "Ok" , null)
                        .setNegativeButton( "Cancel" , null )
                        .show() ;
            }
    }

    public void OnRefreshClick(View view) //Refreshes activity to acquire new location or when enabling internet and location
    {
        finish();
        startActivity(getIntent());
    }

    public void OnProceedClick(View view)
    {
        String cityString = city.getText().toString();
        if (TextUtils.isEmpty(cityString))
        {
            Toast.makeText(this, "Please click refresh.", Toast.LENGTH_LONG).show();
        }else
            {
                Intent temp = new Intent(MainActivity.this, Login.class);
                temp.putExtra("lat",latias.getText());
                temp.putExtra("lon",latios.getText());
                startActivity(temp);
            }

    }

    @Override
    public void onLocationChanged(Location location) {           //Displays users current area, mainly used for weather feature.
        progressBar.setVisibility(View.VISIBLE);
        latias.setText(""+location.getLatitude());
        latios.setText(""+location.getLongitude());

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            progressBar.setVisibility(View.GONE);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String cityName = addresses.get(0).getLocality();
        String countryName = addresses.get(0).getCountryName();

        city.setText(cityName);
        country.setText(countryName);

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Log.d("Latitude","status");
    }

    @Override
    public void onProviderEnabled(String provider) {
        Log.d("Latitude","enable");
    }

    @Override
    public void onProviderDisabled(String provider) {
        Log.d("Latitude","disable");
    }
}
