package com.example.sanmaps;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.AnimationDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.ImageButton;

public class Contact extends AppCompatActivity {
    ImageButton dial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        ConstraintLayout constraintLayout = findViewById(R.id.contactPage);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        dial = findViewById(R.id.btnDial);
    }

    public void onDialClick(View v) {

        if (ContextCompat.checkSelfPermission(Contact.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(Contact.this, new String[]{Manifest.permission.CALL_PHONE},1);
        }else{
            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:1234567890")));
        }

    }

    public void onMail(View v) {

        startActivity(new Intent(Contact.this, Email.class));

    }
}
