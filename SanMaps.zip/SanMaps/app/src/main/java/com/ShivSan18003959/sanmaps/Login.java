package com.ShivSan18003959.sanmaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {

    Double LAT ;
    Double LON ;

    private EditText email,pass;
    private ProgressBar progressBar;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Intent intent = getIntent();
        LAT = Double.parseDouble(intent.getStringExtra("lat"));
        LON = Double.parseDouble(intent.getStringExtra("lon"));

        InitializeFields();
        progressBar.setVisibility(View.GONE);
        mAuth = FirebaseAuth.getInstance();

    }

    public void onLoginClick(View view)
    {
        userLogin();
    }

    public void onRegisterClick(View view)
    {
        startActivity(new Intent(Login.this, Register.class));
    }

    private void userLogin()  //Checks if user exists in my Firebase Database
    {
        String userEmail = email.getText().toString();
        String password = pass.getText().toString();

        if (TextUtils.isEmpty(userEmail) || TextUtils.isEmpty(password))
        {
            Toast.makeText(this, "Please enter all fields...", Toast.LENGTH_SHORT).show();
        }else
        {
            progressBar.setVisibility(View.VISIBLE);
            mAuth.signInWithEmailAndPassword(userEmail,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    progressBar.setVisibility(View.GONE);
                    if (task.isSuccessful())
                    {
                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        Intent temp = new Intent(Login.this, Home.class);
                        temp.putExtra("lat2",LAT.toString());
                        temp.putExtra("lon2",LON.toString());
                        startActivity(temp);
                        Toast.makeText(Login.this, "Signed in successfully", Toast.LENGTH_SHORT).show();
                    }else
                    {
                        String message = task.getException().toString();
                        Toast.makeText(Login.this, "Error: "+message, Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    private void InitializeFields()
    {
        email = findViewById(R.id.etEmail);
        pass = findViewById(R.id.etPassword);
        progressBar = findViewById(R.id.progressbarmain);
    }
}
