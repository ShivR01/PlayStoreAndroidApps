package com.ShivSan18003959.sanmaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Settings extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private FirebaseUser currentuser;
    private DatabaseReference myRef;
    private String userID;

    private EditText user;
    private Spinner modeT, measure;
    private ProgressBar profBar;
    private Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        ConstraintLayout constraintLayout = findViewById(R.id.settingPage);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        InitializeFields();

        mAuth = FirebaseAuth.getInstance();
        currentuser = mAuth.getCurrentUser();
        userID = currentuser.getUid();
        profBar.setVisibility(View.VISIBLE);

        mDatabase = FirebaseDatabase.getInstance();
        myRef = mDatabase.getReference("Users");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showData(dataSnapshot.child(userID));
                profBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void onSaveClick(View view)
    {
        User fbUser = new User(user.getText().toString(), FirebaseAuth.getInstance().getCurrentUser().getEmail(), modeT.getSelectedItem().toString(), measure.getSelectedItem().toString());
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Users");
        myRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(fbUser).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if (task.isSuccessful())
                {
                    Toast.makeText(Settings.this, "User profile edited successfully...", Toast.LENGTH_SHORT).show();
                }else{
                    String message = task.getException().toString();
                    Toast.makeText(Settings.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showData(DataSnapshot dataSnapshot)
    {

        user.setText(dataSnapshot.getValue(User.class).getUserName());

        ArrayAdapter myAdap1 = (ArrayAdapter) modeT.getAdapter();
        int spinnerPosition1 = myAdap1.getPosition(dataSnapshot.getValue(User.class).getModeTransport());
        modeT.setSelection(spinnerPosition1);

        ArrayAdapter myAdap2 = (ArrayAdapter) measure.getAdapter();
        int spinnerPosition2 = myAdap2.getPosition(dataSnapshot.getValue(User.class).getMeasurement());
        measure.setSelection(spinnerPosition2);

    }

    private void InitializeFields()
    {
        user = findViewById(R.id.etUser);
        modeT = findViewById(R.id.spinModeTransportSetting);
        measure = findViewById(R.id.spinMeasureSetting);
        save = findViewById(R.id.btnSave);
        profBar = findViewById(R.id.profileProgBar);
    }

}
